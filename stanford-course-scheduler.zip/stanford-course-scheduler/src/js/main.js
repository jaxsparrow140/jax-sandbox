// Course data (simulated based on research findings)
const courseData = [
    {
        code: "OIT 367",
        title: "Business Intelligence from Big Data",
        instructor: "Professor Ashish Goel",
        description: "Advanced applications level of Data Analysis and Decision Making. Analyze real-world situations where significant competitive advantage can be obtained through large-scale data analysis. Apply technologies such as Artificial Intelligence and Python to analyze data sets and generate knowledge that informs decision-making. Covers fundamentals of data-driven decision-making, including statistical modeling, machine learning, and experimental design.",
        tags: ["AI", "Machine Learning", "Data Science", "Business Analytics"],
        category: "ai"
    },
    {
        code: "OIT 368",
        title: "Design for Disruption",
        instructor: "Professor Stefanos Zenios",
        description: "Understand disruption theory and how to apply it to business strategy. Learn how to develop and test disruption hypotheses using design thinking and lean startup methodologies. Examine real-world cases including Impossible Foods, Warby Parker, Amazon Web Services, and Uber.",
        tags: ["Innovation", "Disruption", "Strategy", "Design Thinking"],
        category: "business"
    },
    {
        code: "AI 301",
        title: "AI and Data Science Strategy",
        instructor: "Professor Kuang Xu",
        description: "Exclusive GSB course on leveraging AI and data science for strategic advantage. Learn how to identify business problems that can be solved with AI, evaluate AI solutions, and implement AI initiatives in organizations. Focus on practical applications in marketing, finance, operations, and human resources.",
        tags: ["AI Strategy", "Data Science", "Business Strategy", "Implementation"],
        category: "ai"
    },
    {
        code: "MS&E 270",
        title: "Machine Learning & Causal Inference",
        instructor: "Professor Susan Athey",
        description: "Introduction to estimation of average treatment effects using data from randomized controlled trials or settings where the unconfoundedness assumption holds. Focus on how machine learning methods can improve upon traditional methods for estimation. Learn to measure the effects of interventions and understand heterogeneous impacts.",
        tags: ["Machine Learning", "Causal Inference", "Statistics", "Experimental Design"],
        category: "data"
    },
    {
        code: "CS 229",
        title: "Machine Learning",
        instructor: "Professor Andrew Ng",
        description: "Comprehensive introduction to machine learning, data mining, and statistical pattern recognition. Topics include supervised learning (parametric/nonparametric algorithms, support vector machines, kernels, neural networks), unsupervised learning (clustering, dimensionality reduction, recommender systems), and best practices in machine learning.",
        tags: ["Machine Learning", "AI", "Algorithms", "Neural Networks"],
        category: "ai"
    },
    {
        code: "OIT 384",
        title: "Biodesign Innovation: Needs Finding and Concept Creation",
        instructor: "Professor Paul Yock",
        description: "Learn the biodesign innovation process to identify unmet clinical needs and develop innovative solutions. Apply design thinking principles to healthcare challenges. Focus on human-centered design and rapid prototyping.",
        tags: ["Innovation", "Design Thinking", "Healthcare", "Biodesign"],
        category: "business"
    },
    {
        code: "MS&E 238",
        title: "Data Science for Business",
        instructor: "Professor Robert L. Miller",
        description: "Practical applications of data science in business contexts. Learn to collect, clean, analyze, and visualize data to inform business decisions. Focus on statistical modeling, predictive analytics, and communicating insights to stakeholders.",
        tags: ["Data Science", "Business Analytics", "Statistics", "Visualization"],
        category: "data"
    },
    {
        code: "GSB 320",
        title: "Digital Transformation: Leading Organizational Change in the Age of AI",
        instructor: "Professor Michael Luca",
        description: "Explore how AI is transforming industries and organizations. Learn strategies for leading digital transformation initiatives, managing change, and building AI-ready organizations. Case studies from leading companies in finance, retail, healthcare, and technology.",
        tags: ["AI Strategy", "Digital Transformation", "Organizational Change", "Leadership"],
        category: "ai"
    }
];

// DOM elements
const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const resultsList = document.getElementById('results-list');
const recommendationsList = document.getElementById('recommendations-list');
const filterButtons = document.querySelectorAll('.filter-btn');

// Initialize the app
function init() {
    // Display recommended courses
    displayRecommendedCourses();
    
    // Add event listeners
    searchButton.addEventListener('click', performSearch);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Update active filter
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Filter results
            const filter = this.getAttribute('data-filter');
            filterCourses(filter);
        });
    });
    
    // Set initial filter
    filterCourses('all');
}

// Display recommended courses
function displayRecommendedCourses() {
    const aiCourses = courseData.filter(course => course.category === 'ai');
    const topRecommendations = aiCourses.slice(0, 3);
    
    recommendationsList.innerHTML = '';
    
    topRecommendations.forEach(course => {
        const courseCard = document.createElement('div');
        courseCard.className = 'course-card';
        
        const tagsHTML = course.tags.map(tag => `<span class="tag ${tag.toLowerCase()}">${tag}</span>`).join('');
        
        courseCard.innerHTML = `
            <div class="course-code">${course.code}</div>
            <div class="course-title">${course.title}</div>
            <div class="course-instructor">by ${course.instructor}</div>
            <div class="course-description">${course.description}</div>
            <div class="course-tags">${tagsHTML}</div>
            <button class="add-button" data-code="${course.code}">Add to Schedule</button>
        `;
        
        // Add event listener to add button
        courseCard.querySelector('.add-button').addEventListener('click', function() {
            addToSchedule(course.code);
        });
        
        recommendationsList.appendChild(courseCard);
    });
}

// Perform search based on natural language input
function performSearch() {
    const query = searchInput.value.trim().toLowerCase();
    
    if (!query) {
        resultsList.innerHTML = '<div class="no-results">Please enter a search query</div>';
        return;
    }
    
    // Show loading state
    resultsList.innerHTML = '<div class="loading">Searching for courses...</div>';
    
    // Simulate network delay
    setTimeout(() => {
        const results = searchCourses(query);
        displaySearchResults(results);
    }, 500);
}

// Search courses based on natural language query
function searchCourses(query) {
    if (!query) return [];
    
    // Keywords for different categories
    const aiKeywords = ['ai', 'artificial intelligence', 'machine learning', 'ml', 'deep learning', 'neural network', 'nlp', 'natural language', 'predictive', 'analytics', 'data science', 'algorithm', 'model', 'training', 'neural', 'tensor', 'pytorch', 'tensorflow', 'sklearn', 'scikit', 'python', 'r', 'statistical'];
    const dataKeywords = ['data science', 'analytics', 'statistical', 'statistics', 'visualization', 'dashboard', 'report', 'query', 'database', 'sql', 'big data', 'hadoop', 'spark', 'etl', 'data pipeline', 'data warehouse'];
    const businessKeywords = ['business', 'strategy', 'marketing', 'finance', 'operations', 'supply chain', 'hr', 'human resources', 'leadership', 'management', 'decision', 'optimization', 'pricing', 'revenue', 'customer', 'retention'];
    
    // Filter courses based on keywords
    const results = courseData.filter(course => {
        // Check if query matches any course attributes
        const courseText = `${course.code} ${course.title} ${course.instructor} ${course.description} ${course.tags.join(' ')}`.toLowerCase();
        
        // Exact match
        if (courseText.includes(query)) {
            return true;
        }
        
        // Keyword matching
        if (aiKeywords.some(keyword => query.includes(keyword))) {
            return course.category === 'ai';
        }
        
        if (dataKeywords.some(keyword => query.includes(keyword))) {
            return course.category === 'data';
        }
        
        if (businessKeywords.some(keyword => query.includes(keyword))) {
            return course.category === 'business';
        }
        
        // General text search
        return courseText.includes(query);
    });
    
    return results;
}

// Display search results
function displaySearchResults(courses) {
    resultsList.innerHTML = '';
    
    if (courses.length === 0) {
        resultsList.innerHTML = '<div class="no-results">No courses found matching your search. Try using keywords like "AI", "machine learning", or "data science".</div>';
        return;
    }
    
    courses.forEach(course => {
        const courseCard = document.createElement('div');
        courseCard.className = 'course-card';
        
        const tagsHTML = course.tags.map(tag => `<span class="tag ${tag.toLowerCase()}">${tag}</span>`).join('');
        
        courseCard.innerHTML = `
            <div class="course-code">${course.code}</div>
            <div class="course-title">${course.title}</div>
            <div class="course-instructor">by ${course.instructor}</div>
            <div class="course-description">${course.description}</div>
            <div class="course-tags">${tagsHTML}</div>
            <button class="add-button" data-code="${course.code}">Add to Schedule</button>
        `;
        
        // Add event listener to add button
        courseCard.querySelector('.add-button').addEventListener('click', function() {
            addToSchedule(course.code);
        });
        
        resultsList.appendChild(courseCard);
    });
}

// Filter courses by category
function filterCourses(category) {
    let filteredCourses;
    
    if (category === 'all') {
        filteredCourses = courseData;
    } else {
        filteredCourses = courseData.filter(course => course.category === category);
    }
    
    displaySearchResults(filteredCourses);
}

// Add course to schedule (simulated)
function addToSchedule(courseCode) {
    // In a real app, this would save to local storage or a database
    const course = courseData.find(c => c.code === courseCode);
    
    if (course) {
        // Show confirmation
        alert(`Added ${course.code} - ${course.title} to your schedule!\n\nNote: This is a simulation. In a real app, your schedule would be saved to your account.`);
        
        // In a real implementation, we would:
        // 1. Save to localStorage
        // 2. Update the UI to show the course in a "My Schedule" section
        // 3. Potentially sync with Stanford's official system
    }
}

// Initialize the app when the DOM is loaded
document.addEventListener('DOMContentLoaded', init);