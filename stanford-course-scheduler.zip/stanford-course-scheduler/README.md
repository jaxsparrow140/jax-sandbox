# Stanford GSB Course Scheduler

A simple, natural language interface for finding and scheduling AI-centric courses at Stanford GSB.

## Overview

This is a lightweight web application designed specifically for Stanford GSB students to discover and plan courses for the upcoming quarter. The app provides a natural language interface to search for courses and recommends AI-focused courses that are particularly relevant for business students.

## Features

- **Natural Language Search**: Ask questions like "Show me AI courses" or "Find courses with machine learning"
- **AI Course Recommendations**: Curated list of top AI, machine learning, and data science courses for GSB students
- **Category Filtering**: Filter courses by category (AI, Data Science, Business Analytics)
- **Course Details**: View course codes, titles, instructors, descriptions, and tags
- **Add to Schedule**: Simulated functionality to "add" courses to your personal schedule
- **Responsive Design**: Works on desktop, tablet, and mobile devices

## Recommended AI-Centric Courses for GSB Students

Based on research into Stanford GSB offerings, the following courses are highly recommended:

1. **OIT 367: Business Intelligence from Big Data** - Covers AI, machine learning, and data-driven decision making
2. **AI and Data Science Strategy** - Exclusive GSB course on leveraging AI for strategic advantage
3. **MS&E 270: Machine Learning & Causal Inference** - Focus on measurement of intervention effects
4. **GSB 320: Digital Transformation: Leading Organizational Change in the Age of AI** - Strategic leadership in AI adoption

## How to Use

1. Open `index.html` in any modern web browser (Chrome, Firefox, Safari, Edge)
2. Use the search bar to ask natural language questions about courses
   - Examples: "Show me AI courses", "Find machine learning classes", "What data science courses are available?"
3. Click on category filters to view courses by type
4. Click "Add to Schedule" on any course to simulate adding it to your plan

## Technical Details

- **Frontend**: HTML, CSS, JavaScript
- **No Backend Required**: All functionality runs in the browser
- **Data Source**: Simulated data based on publicly available Stanford GSB course information
- **No External Dependencies**: All assets are included locally

## Limitations

- **Data is Simulated**: This application does not connect to Stanford's official course registry API, which requires authentication.
- **Real-time Data**: Course offerings, instructors, and descriptions may change. Always verify information on the official Stanford Explore Courses website: https://explorecourses.stanford.edu/
- **No Enrollment**: This is a planning tool only. Enrollment must be done through Stanford's official systems.
- **No Account System**: Schedule data is not saved between sessions.

## Development

This application was developed in the `~/jax-sandbox/stanford-course-scheduler/` directory.

To modify the application:

1. Edit the HTML in `index.html`
2. Modify the CSS in `src/css/style.css`
3. Update the JavaScript logic in `src/js/main.js`
4. Add new course data in the `courseData` array in `src/js/main.js`

## Acknowledgments

This application is designed for educational purposes and is not affiliated with Stanford University. All course information is based on publicly available data from Stanford's website.

Created for the OpenClaw evaluation experiment by Jax Sparrow.